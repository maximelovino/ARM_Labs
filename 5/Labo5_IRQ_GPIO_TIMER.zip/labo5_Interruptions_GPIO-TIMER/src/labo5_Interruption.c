/*
===============================================================================
 Name        : labo5_Interruption_GPIO_TIMER.c
 Author      : D. Bechevet, V. Pilloux, A. Lescourt, F. Vannel
 Copyright   : HES-SO hepia
 Year        : 2015-2016
===============================================================================
 */


#include "config_LPC1769.h"
#include <stdint.h>
#include <stdbool.h>

// #include "../../MyLab_lib/inc/GPIO.h"

/* function prototypes */
void exercice1(void);
void exercice2(void);
void exercice3(void);
void exercice4(void);

/* global variables */
uint8_t exo;		// change this variable with the exercise number you want to test

/***********************************
 * function     : exercice1
 * arguments    : none
 * return value : none
 *   COMPTEUR IRQ GPIO
 ***********************************/
void exercice1(void)
{


}

/***********************************
 * function     : exercice2
 * arguments    : none
 * return value : none
 *   CHENILLARD IRQ GPIO
 ***********************************/
void exercice2(void)
{

}

/***********************************
 * function     : exercice3
 * arguments    : none
 * return value : none
 *   CHENILLARD IRQ TIMER
 ***********************************/
void exercice3(void)
{

}

/***********************************
 * function     : exercice4
 * arguments    : none
 * return value : none
 *   Click et double Click
 ***********************************/
void exercice4(void)
{

}




/***********************************
 * function     : main
 * arguments    : none
 * return value : none
 * Startup function
 ***********************************/
int main(void) {

	exo = 1;    // change this number with the exercise number you want to test
	while (true)
	{
		switch(exo){					// select the function corresponding to the exercise to test
		case 1 : exercice1(); break;
		case 2 : exercice2(); break;
		case 3 : exercice3(); break;
		case 4 : exercice4(); break;
		}

	}
}
