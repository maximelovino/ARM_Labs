/*
===============================================================================
 Name        : labo4_GPIO.c
 Author      : D. Bechevet, V. Pilloux, A. Lescourt, F. Vannel
 Copyright   : HES-SO hepia
 Year        : 2014-2015-2016
===============================================================================
 */


#include "config_LPC1769.h"
#include <stdint.h>
#include <stdbool.h>

// #include "../MyLab_lib/inc/MyLab_GPIO.h"

/* function prototypes */
extern void exercice1(void);
void exercice2(void);
void exercice3(void);
void exercice4(void);
void exercice5(void);
void exercice6(void);



/* global variables */
uint8_t exo;		// change this variable with the exercise number you want to test

/***********************************
 * function     : init
 * arguments    : none
 * return value : none
 *   initialisation de la carte MyLab
 ***********************************/
void init(void)
{

}


/***********************************
 * function     : exercice2
 * arguments    : none
 * return value : none
 *   AFFICHAGE CLIGNOTANT
 ***********************************/
void exercice2(void)
{

}

/***********************************
 * function     : exercice3
 * arguments    : none
 * return value : none
 *   COMPTEUR 8 BITS A DEUX VITESSES
 ***********************************/
void exercice3(void)
{

}

/***********************************
 * function     : exercice4
 * arguments    : none
 * return value : none
 *   COMPTEUR 8 BITS MANUEL
 ***********************************/
void exercice4(void)
{

}

/***********************************
 * function     : exercice5
 * arguments    : none
 * return value : none
 *   CHENILLARD
 ***********************************/
void exercice5(void)
{

}

/***********************************
 * function     : exercice6
 * arguments    : none
 * return value : none
 *   CHENILLARD REBONDISSANT
 ***********************************/
void exercice6(void)
{

}

/***********************************
 * function     : main
 * arguments    : none
 * return value : none
 * Startup function
 ***********************************/
int main(void) {

	exo = 1;    // change this number with the exercise number you want to test

	init();

	while (true)
	{
		switch(exo){					// select the function corresponding to the exercise to test
		case 1 : exercice1(); break;
		case 2 : exercice2(); break;
		case 3 : exercice3(); break;
		case 4 : exercice4(); break;
		case 5 : exercice5(); break;
		case 6 : exercice6(); break;
		}

	}
}
